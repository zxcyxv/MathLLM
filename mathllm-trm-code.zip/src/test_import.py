def hello():
    print("MathLLM src imported successfully!")
    return True
